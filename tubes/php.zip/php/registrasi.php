<?php 
require 'functions.php';

if(isset($_POST["register"]) ) {

    if(registrasi($_POST) > 0 ) {
        echo "<script>
                alert('user baru berhasil ditambahkan!');
                document.location.href = 'login.php';
                </script>";
    } else {
        echo mysqli_error($conn);
    }
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="css/styleregister.css">
    <script src="https://kit.fontawesome.com/208aa639b3.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="css/responsive.css">

    <title>Yupi Sehat</title>
  </head>
  <body>
<!-- Awal Navbar-->
<nav class="navbar navbar-expand-lg" style="background-color: #3B3738 ;">
    <div class="container">
        <a class="navbar-brand" href="#">
            <img src="img/logo.jpg" alt="" width="35" height="35" class="d-inline-block">
            Yupi <strong>sehat</strong>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                  <a class="nav-link" href="pelayanan.html">Beranda</a>
                <li class="nav-item">
                  <a class="nav-link" href="registrasi.php">Daftar</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="login.php">Masuk</a>
                </li>
              </ul>
        </div>
    </div>
  </nav>
    <!-- Akhir Navbar-->
      <!-- Awal Form register -->

      <h1>Halaman Registrasi</h1>

      <form action="" method="post">
        
        <ul>
          <li>
            <label for="email">Email : </label>
            <input type="email" name="email" id="email" required>
          </li>
          <li>
            <label for="password">Password : </label>
            <input type="password" name="password" id="password" required>
          </li>
          <li>
            <label for="password2">Konfirmasi Password : </label>
            <input type="password" name="password2" id="password2" required>
          </li>
          <li>
            <button type="submit" name="register">Register</button>
          </li>
        </ul>

      </form>


    <!-- <div class="container">
        <form class="form-container">
            <h3 class="title-name">Daftar</h3>
            <div class="row mt-2">
                <div class="col-md-7">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <div class="input-group mb-3">
                            <span class="input-group-text" id="basic-addon1"><i class="fas fa-user"></i></span>
                            <input type="email" class="form-control" id="email" 
                            aria-describedby="emailHelp" placeholder="email">
                        </div>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <div class="input-group mb-3">
                            <span class="input-group-text" id="basic-addon1"><i class="fas fa-key"></i></span>
                            <input type="password" class="form-control" id="password" 
                            aria-describedby="emailHelp" placeholder="password">
                        </div>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="mb-3">
                        <label for="password2" class="form-label">Konfirmasi Password</label>
                        <div class="input-group mb-3">
                            <span class="input-group-text" id="basic-addon1"><i class="fas fa-key"></i></span>
                            <input type="password" class="form-control" id="password2" 
                            aria-describedby="emailHelp" placeholder="konfirmasi_password">
                        </div>
                    </div>
            </div>
            <div class="mb-3 form-check">
              <input type="checkbox" class="form-check-input" id="exampleCheck1">
              <label class="form-check-label" for="exampleCheck1">Saya Menyetujui <span class="text-color">Syarat & Ketentuan</span> Yang Berlaku <span class="text-color">*</span></label>
            </div>
            <div>
                <div class="row mt-5">
                    <div class="col-md-6 d-grid">
                        <button type="submit" class="btn btn-outline-primary" name="registrasi" >Daftar</button>
                    </div>
                    <div class="col-md-6 d-grid">
                        <button type="reset" class="btn btn-outline-danger">Hapus Data</button>
                    </div>
                </div>
            </div>
            <div class="mt-2">
                <label>Kamu Sudah Punya Akun? <a href="login.php" class="text-link">Masuk Disini</a></label>
            </div>
          </form>
    </div> -->

    <!-- Akhir Form register -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

  </body>
</html>