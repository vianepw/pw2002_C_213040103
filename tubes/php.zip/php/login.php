<?php 

require 'functions.php';

if (isset($_POST['login'])) {
  $conn = koneksi();
  $email= $_POST['email'];
  $password = $_POST['password'];

  $product = mysqli_query($conn, "SELECT * FROM user WHERE email = '$email'");

  //cek username
  if(mysqli_num_rows($product) === 1 ) {

      //cek password
      $row = mysqli_fetch_assoc($product);
      if(password_verify($password, $row["password"])) {
        if ($row['role']=="admin") {
          $_SESSION['id_admin'] = $row['id'];
          $_SESSION['role'] = "admin";
            header("location:admin.php");
      } else if ($row['role']=="user") {
          $_SESSION['id_user'] = $row['id'];
          $_SESSION['role'] = "user";
            header("location:user.php");
      }
      }
  }

  $error = true;
}
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Yupi Sehat</title>
  </head>
  <body>

<!-- Awal Navbar-->
<nav class="navbar navbar-expand-lg" style="background-color: #3B3738;">
    <div class="container">
        <a class="navbar-brand" href="#">
            <img src="img/logo.jpg" alt="" width="35" height="35" class="d-inline-block">
            Yupi <strong>sehat</strong>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                  <a class="nav-link" href="pelayanan.html">Beranda</a>
                <li class="nav-item">
                  <a class="nav-link" href="registrasi.php">Daftar</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="login.php">Masuk</a>
                </li>
              </ul>
        </div>
    </div>
  </nav>
    <!-- Akhir Navbar-->

    <h1>Halaman Login</h1>

<?php if (isset($error)) :?>
	<p style="color: red; font-style: italic;">username/password salah</p>
<?php endif; ?>

  <div class="container">
  <form action="" method="post">
	<h3 class="textjudul mb-5 mt-2">Masuk</h3>
  
  <ul>
		<li>
			<label for="email">Email :</label>
			<input type="email" name="email" id="email">
		</li>
		<li>
			<label for="password">Password :</label>
			<input type="password" name="password" id="password">
		</li>
		<li>
			<button type="submit" name="login">Login</button>
		</li>
	</ul>

</form>

  </div>



    <!-- <div class="container">
        <form class="form-container">
            <h3 class="textjudul mb-5 mt-2">Masuk</h3>
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label textForm">Email</label>
              <div class="input-group mb-3">
                <span class="input-group-text" id="basic-addon1">@</span>
              <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Masukkan Email"
              name="email">
              </div>
              </div>
            <div class="mb-3">
              <label for="exampleInputPassword1" class="form-label textForm ">Password</label>
              <div class="input-group mb-3">
              <span class="input-group-text" id="basic-addon1"><i class="far fa-envelope"></i></span>
              <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Masukkan Password" name="password">
              </div>
            </div>
            <div style="margin-top: -13px;" class="text-end">
              <a href="#" class="textForm text-hover">Lupa Password?</a>
            </div>
            <div class="d-grid mt-5">
            <button type="submit" class="btn btn-outline-primary textForm">Masuk</button>
            <div>
              <div class="mt-1">
                <span class="textForm">Belum Punya Akun? <a href="registrasi.php" class="textForm text-hover">Daftar</a></span>
              </div>
          </form>
    </div> -->
   

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

  </body>
</html>